<template>

<div> </div>


</template>

<script>
export default {
  name: 'Sample',
  data() {

  },
  props: {
  },
  mounted() {
  }
};
</script>

<style scoped>
.sample{
  width:100px;
}
</style>
