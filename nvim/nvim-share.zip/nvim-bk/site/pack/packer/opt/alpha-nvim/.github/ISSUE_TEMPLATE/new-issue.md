---
name: New Issue
about: new issue template
title: ''
labels: ''
assignees: ''

---

please *read the documentation* before asking questions about configuration or creating a feature request

for bugs: provide the expected behavior and the actual behavior, and screenshots if you want to be nice
